package com.dms.dms_backend.api.dto;


import lombok.Data;


@Data
public class LoginDTO {
private String email;
private String password;
}