package com.dms.dms_backend.service;

import com.dms.dms_backend.api.dto.LoginDTO;
import com.dms.dms_backend.api.dto.RegisterUserDTO;
import com.dms.dms_backend.api.dto.VerifyOtpDTO;
import com.dms.dms_backend.api.dto.CreateUserDTO;
import com.dms.dms_backend.domain.User;
import com.dms.dms_backend.repo.UserRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OtpService otpService;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public User register(RegisterUserDTO dto) {
        User user = new User();
        user.setEmail(dto.getEmail());
        user.setName(dto.getName());
        user.setRole(User.Role.valueOf(dto.getRole().toUpperCase()));
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setVerified(false);

        userRepository.save(user);
        otpService.generateAndSendOtp(user.getEmail());

        return user;
    }

    public String verifyOtp(VerifyOtpDTO dto) {
        boolean isValid = otpService.verifyOtp(dto.getEmail(), dto.getOtp());
        if (isValid) {
            Optional<User> userOptional = userRepository.findByEmail(dto.getEmail());
            if (userOptional.isPresent()) {
                User user = userOptional.get();
                user.setVerified(true);
                userRepository.save(user);
                return "OTP verified. User is now verified.";
            } else {
                return "User not found.";
            }
        }
        return "Invalid OTP.";
    }

    public String login(LoginDTO dto) {
        Optional<User> userOptional = userRepository.findByEmail(dto.getEmail());
        if (userOptional.isPresent()) {
            User user = userOptional.get();

            if (!user.isVerified()) {
                return "User not verified. Please complete OTP verification.";
            }

            if (passwordEncoder.matches(dto.getPassword(), user.getPassword())) {
                return "Login successful";
            } else {
                return "Invalid password";
            }
        } else {
            return "User not found";
        }
    }
    
//     public User create(CreateUserDTO dto) {
//     User user = new User();
//     user.setEmail(dto.getEmail());
//     user.setName(dto.getName());
//     user.setPassword(passwordEncoder.encode(dto.getPassword()));
//     user.setRole(User.Role.valueOf(dto.getRole()));
//     user.setVerified(true);
//     return userRepository.save(user);
// }

public User create(CreateUserDTO dto) {
    User user = new User();
    user.setEmail(dto.getEmail());
    user.setName(dto.getName());

    // If password not provided, assign default
    String rawPass = dto.getPassword() == null || dto.getPassword().isBlank()
                     ? "changeme123" 
                     : dto.getPassword();

    user.setPassword(passwordEncoder.encode(rawPass));
    user.setRole(User.Role.valueOf(dto.getRole()));
    user.setVerified(true);
    return userRepository.save(user);
}


public List<User> getAll() {
    return userRepository.findAll();
}

public User update(Long id, CreateUserDTO dto) {
    User user = userRepository.findById(id).orElseThrow();
    user.setName(dto.getName());
    user.setPassword(passwordEncoder.encode(dto.getPassword()));
    user.setRole(User.Role.valueOf(dto.getRole()));
    return userRepository.save(user);
}

public void delete(Long id) {
    userRepository.deleteById(id);
}

}
