// File: com.dms.dms_backend.service.ShelterService.java
package com.dms.dms_backend.service;

import com.dms.dms_backend.api.dto.CreateShelterDTO;
import com.dms.dms_backend.api.dto.ShelterDTO;
import com.dms.dms_backend.domain.Shelter;
import com.dms.dms_backend.repo.ShelterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dms.dms_backend.repo.IncidentRepository;
import com.dms.dms_backend.repo.ShelterRepository;
import com.dms.dms_backend.domain.Incident;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ShelterService {

    @Autowired private ShelterRepository shelterRepository;
    @Autowired private IncidentRepository incidentRepository;

    public ShelterDTO create(CreateShelterDTO dto) {
        Shelter shelter = new Shelter();
        shelter.setName(dto.getName());
        shelter.setAddress(dto.getAddress());
        shelter.setLat(dto.getLat());
        shelter.setCapacity(dto.getCapacity());
        shelter.setLng(dto.getLng()); 

        if (dto.getIncidentId() != null) {
            Incident incident = incidentRepository.findById(dto.getIncidentId())
                    .orElseThrow(() -> new RuntimeException("Incident not found"));
            shelter.setIncident(incident);
        }

        Shelter saved = shelterRepository.save(shelter);
        return convertToDTO(saved);
    }

    private ShelterDTO convertToDTO(Shelter shelter) {
        ShelterDTO dto = new ShelterDTO();
        dto.setId(shelter.getId());
        dto.setName(shelter.getName());
        dto.setCapacity(shelter.getCapacity());
        dto.setIncidentId(shelter.getIncident() != null ? shelter.getIncident().getId() : null);
        // add more if needed
        return dto;
    }
    
//    public ShelterDTO create(CreateShelterDTO dto) {
//        Shelter s = Shelter.builder()
//                .name(dto.name)
//                .address(dto.address)
//                .capacity(dto.capacity)
//                .lat(dto.lat)
//                .lng(dto.lng)
//                .build();
//        return toDTO(shelterRepository.save(s));
//    }


    public List<ShelterDTO> getAll() {
    return shelterRepository.findAll().stream()
            .map(this::toDTO) // now includes incidentId
            .collect(Collectors.toList());
}

    public ShelterDTO update(Long id, CreateShelterDTO dto) {
        Shelter s = shelterRepository.findById(id).orElseThrow();
        s.setName(dto.name);
        s.setAddress(dto.address);
        s.setCapacity(dto.capacity);
        s.setLat(dto.lat);
        s.setLng(dto.lng);
            if (dto.getIncidentId() != null) {
        Incident incident = incidentRepository.findById(dto.getIncidentId())
            .orElseThrow(() -> new RuntimeException("Incident not found"));
        s.setIncident(incident);
    }
        Shelter updated = shelterRepository.save(s);
        return toDTO(shelterRepository.save(s));
    }

    public void delete(Long id) {
        shelterRepository.deleteById(id);
    }

    private ShelterDTO toDTO(Shelter s) {
        return ShelterDTO.builder()
                .id(s.getId())
                .name(s.getName())
                .address(s.getAddress())
                .capacity(s.getCapacity())
                .lat(s.getLat())
                .lng(s.getLng())
                .incidentId(s.getIncident() != null ? s.getIncident().getId() : null)
                .build();
    }
}
