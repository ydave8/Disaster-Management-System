package com.dms.dms_backend.api.dto;

import com.dms.dms_backend.domain.Alert.Severity;
import jakarta.validation.constraints.*;
import java.time.Instant;

public record CreateAlertDTO(
  @NotBlank String title,
  @NotBlank String message,
  @NotBlank String area,
  Severity severity,
  @NotNull  Instant  expiresAt
) {}
