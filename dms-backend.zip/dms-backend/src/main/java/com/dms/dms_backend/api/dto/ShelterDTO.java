// File: com.dms.dms_backend.api.dto.ShelterDTO.java
package com.dms.dms_backend.api.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ShelterDTO {
    public Long id;
    private Long incidentId;
    public String name;
    public String address;
    public int capacity;
    public double lat;
    public double lng;
}
