//package com.dms.dms_backend.service;
//
//import com.dms.dms_backend.domain.SosRequest;
//import com.dms.dms_backend.repo.SosRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class SosService {
//
//    @Autowired private SosRepository sosRepository;
//
//    public SosRequest save(SosRequest sos) {
//        return sosRepository.save(sos);
//    }
//
//    public List<SosRequest> getAll() {
//        return sosRepository.findAll();
//    }
//}

package com.dms.dms_backend.service;

import com.dms.dms_backend.domain.SosRequest;
import com.dms.dms_backend.repo.SosRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;


import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class SosService {

  private final SosRepository repo;
  private final JavaMailSender mail;

  private static final String ADMIN_EMAIL = "admin@example.com"; // You can load this from config if needed

  @Transactional
  public SosRequest saveSos(SosRequest req) {
    SosRequest saved = repo.save(req);
    sendAdminNotification(saved);
    return saved;
  }

  public List<SosRequest> getAll() {
    return repo.findAll();
  }

  private void sendAdminNotification(SosRequest sos) {
    try {
      SimpleMailMessage msg = new SimpleMailMessage();
      msg.setTo(ADMIN_EMAIL);
      msg.setSubject("🚨 SOS Alert from " + sos.getUserEmail());
      msg.setText("🆘 A new SOS alert was triggered:\n\n" +
        "📧 User: " + sos.getUserEmail() + "\n" +
        "🗺️ Location: " + sos.getLatitude() + ", " + sos.getLongitude() + "\n" +
        "📝 Note: " + sos.getNote() + "\n" +
        "🕒 Time: " + sos.getCreatedAt().toLocalDateTime()
      .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
);

      mail.send(msg);
//      log.info("📧 SOS email sent to admin");
    } catch (Exception e) {
//      log.warn("❌ Failed to send SOS email: {}", e.getMessage());
    }
  }
}
