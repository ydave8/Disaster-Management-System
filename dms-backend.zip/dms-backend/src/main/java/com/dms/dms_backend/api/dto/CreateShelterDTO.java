// File: com.dms.dms_backend.api.dto.CreateShelterDTO.java
package com.dms.dms_backend.api.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CreateShelterDTO {
    public String name;
    public String address;
    public int capacity;
    public double lat;
    public double lng;
    private Long incidentId;
}
