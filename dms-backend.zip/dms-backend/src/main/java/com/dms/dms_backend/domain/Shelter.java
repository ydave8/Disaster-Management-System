// File: com.dms.dms_backend.domain.Shelter.java
package com.dms.dms_backend.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "shelters")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Shelter {

    @ManyToOne
    @JoinColumn(name = "incident_id")
    private Incident incident;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String address;
    private int capacity;
    private double lat;
    private double lng;
    
    public Incident getIncident() {return incident;}

    public void setIncident(Incident incident) {this.incident = incident;}
}
