package com.dms.dms_backend.api.dto;


import lombok.Data;


@Data
public class VerifyOtpDTO {
private String email;
private String otp;
}