package com.dms.dms_backend.api.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateResourceDTO {
    public String type;
    public String description;
    public int quantity;
    public String location;
    private Long incidentId;
}
