package com.dms.dms_backend.api.dto;

import com.dms.dms_backend.domain.Alert.Severity; // adjust if needed
import java.time.Instant;

public record AlertDTO(
  Long id,
  String title,
  String message,
  String area,
  Severity severity,
  Instant expiresAt,
  Instant createdAt
) {}
