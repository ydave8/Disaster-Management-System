package com.dms.dms_backend.service;
import com.dms.dms_backend.api.dto.*;
import com.dms.dms_backend.domain.Incident;
import com.dms.dms_backend.repo.IncidentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service @RequiredArgsConstructor
public class IncidentService {
  private final IncidentRepository repo;
  private final SimpMessagingTemplate ws;

  @Transactional
  public IncidentDTO create(CreateIncidentDTO in){
    var i = Incident.builder()
      .type(in.type()).description(in.description())
      .lat(in.lat()).lng(in.lng()).status(Incident.Status.OPEN)
      .build();
    i = repo.save(i);
    var dto = new IncidentDTO(i.getId(), i.getType(), i.getDescription(), i.getLat(), i.getLng(), i.getStatus());
    ws.convertAndSend("/topic/incidents", dto);
    return dto;
  }

  public List<IncidentDTO> list(Incident.Status status){
    var list = (status == null) ? repo.findAll() : repo.findByStatus(status);
    return list.stream().map(i -> new IncidentDTO(i.getId(), i.getType(), i.getDescription(), i.getLat(), i.getLng(), i.getStatus())).toList();
  }

  @Transactional
  public IncidentDTO updateStatus(Long id, Incident.Status status){
    var i = repo.findById(id).orElseThrow();
    i.setStatus(status);
    var saved = repo.save(i);
    var dto = new IncidentDTO(saved.getId(), saved.getType(), saved.getDescription(), saved.getLat(), saved.getLng(), saved.getStatus());
    ws.convertAndSend("/topic/incidents", dto);
    return dto;
  }
  @Transactional
public IncidentDTO update(Long id, CreateIncidentDTO in) {
  var i = repo.findById(id).orElseThrow();
  i.setType(in.type());
  i.setDescription(in.description());
  i.setLat(in.lat());
  i.setLng(in.lng());
  // status is unchanged unless PATCHed explicitly
  var saved = repo.save(i);
  var dto = new IncidentDTO(saved.getId(), saved.getType(), saved.getDescription(), saved.getLat(), saved.getLng(), saved.getStatus());
  ws.convertAndSend("/topic/incidents", dto);
  return dto;
}

@Transactional
public void delete(Long id) {
  repo.deleteById(id);
  ws.convertAndSend("/topic/incidents", "DELETED:" + id);
}

public IncidentDTO getIncidentById(Long id) {
    var incident = repo.findById(id)
            .orElseThrow(() -> new RuntimeException("Incident not found"));
    return toDto(incident); // or however you convert Incident → IncidentDTO
}

private IncidentDTO toDto(Incident i) {
  return new IncidentDTO(
      i.getId(),
      i.getType(),
      i.getDescription(),
      i.getLat(),
      i.getLng(),
      i.getStatus()
  );
}

}
