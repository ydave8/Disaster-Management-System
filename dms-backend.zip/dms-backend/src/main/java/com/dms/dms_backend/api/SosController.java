package com.dms.dms_backend.api;

import com.dms.dms_backend.domain.SosRequest;
import com.dms.dms_backend.service.SosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/sos")
public class SosController {

    @Autowired private SosService sosService;

    @PostMapping
    public ResponseEntity<SosRequest> createSos(@RequestBody SosRequest sos) {
        SosRequest saved = sosService.saveSos(sos); // triggers email internally
        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public List<SosRequest> getAllSos() {
        return sosService.getAll();
    }

}
