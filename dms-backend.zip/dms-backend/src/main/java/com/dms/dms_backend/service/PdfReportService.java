package com.dms.dms_backend.service;

import com.dms.dms_backend.domain.Incident;
import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Service;
import java.io.ByteArrayOutputStream;

@Service
public class PdfReportService {

  public byte[] generateIncidentReport(Incident incident) throws Exception {
    try (PDDocument doc = new PDDocument()) {
      PDPage page = new PDPage(PDRectangle.A4);
      doc.addPage(page);
      PDPageContentStream stream = new PDPageContentStream(doc, page);

      stream.beginText();
      stream.setFont(PDType1Font.HELVETICA_BOLD, 20);
      stream.setLeading(24f);
      stream.newLineAtOffset(50, 750);
      stream.showText("Incident Report");
      stream.newLine();

      stream.setFont(PDType1Font.HELVETICA, 12);
      stream.newLine();
      stream.showText("ID: " + incident.getId());
      stream.newLine();
      stream.showText("Description: " + incident.getDescription());
      stream.newLine();
      stream.showText("Status: " + incident.getStatus());
      stream.newLine();
      stream.showText("Type: " + incident.getType());
      stream.newLine();
      stream.showText("Latitude: " + incident.getLat());
      stream.newLine();
      stream.showText("Longitude: " + incident.getLng());
      stream.newLine();
      stream.showText("Created At: " + incident.getCreatedAt());
      stream.endText();
      stream.close();

      ByteArrayOutputStream out = new ByteArrayOutputStream();
      doc.save(out);
      return out.toByteArray();
    }
  }
}
