// src/main/java/com/dms/dms_backend/repo/IncidentRepository.java
package com.dms.dms_backend.repo;
import com.dms.dms_backend.domain.Incident;
import com.dms.dms_backend.domain.Incident.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface IncidentRepository extends JpaRepository<Incident, Long> {
  List<Incident> findByStatus(Status status);
}
