package com.dms.dms_backend.api;

import com.dms.dms_backend.api.dto.LoginDTO;
import com.dms.dms_backend.api.dto.RegisterUserDTO;
import com.dms.dms_backend.api.dto.VerifyOtpDTO;
import com.dms.dms_backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.dms.dms_backend.domain.User;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody RegisterUserDTO dto) {
        return ResponseEntity.ok(userService.register(dto));
    }

    @PostMapping("/verify")
    public ResponseEntity<String> verifyOtp(@RequestBody VerifyOtpDTO dto) {
        return ResponseEntity.ok(userService.verifyOtp(dto));
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginDTO dto) {
        return ResponseEntity.ok(userService.login(dto));
    }
}
