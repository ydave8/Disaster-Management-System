/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dms.dms_backend.service;

import com.dms.dms_backend.api.dto.AlertDTO;
import com.dms.dms_backend.api.dto.CreateAlertDTO;
import com.dms.dms_backend.domain.Alert;
import com.dms.dms_backend.repo.AlertRepository;
import com.dms.dms_backend.repo.UserRepository;
import com.dms.dms_backend.domain.User;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import java.time.Instant;
import java.util.List;

@Service @RequiredArgsConstructor @Slf4j

public class AlertService {
  private final AlertRepository repo;
  private final UserRepository userRepo;
  private final SimpMessagingTemplate ws;
  private final JavaMailSender mail;
  
 private final SeverityPredictionService severityService;  
  
@Transactional
public AlertDTO createAndBroadcast(CreateAlertDTO in) {
Alert.Severity severity = in.severity();
if (severity == null) {
    String predicted = severityService.predictSeverity(in.title(), in.message());
    severity = Alert.Severity.valueOf(predicted.toUpperCase());
}

  Alert a = Alert.builder()
    .title(in.title()).message(in.message()).area(in.area())
    .severity(severity).expiresAt(in.expiresAt())
    .build();

  a = repo.save(a);
  AlertDTO dto = new AlertDTO(a.getId(), a.getTitle(), a.getMessage(), a.getArea(),
          a.getSeverity(), a.getExpiresAt(), a.getCreatedAt());

  ws.convertAndSend("/topic/alerts", dto);
  notifyAllUsers(a);
  return dto;
} 
//  @Transactional
//  public AlertDTO createAndBroadcast(CreateAlertDTO in) {
//    Alert a = Alert.builder()
//      .title(in.title()).message(in.message()).area(in.area())
//      .severity(in.severity()).expiresAt(in.expiresAt())
//      .build();
//    a = repo.save(a);
//    AlertDTO dto = new AlertDTO(a.getId(), a.getTitle(), a.getMessage(), a.getArea(),
//            a.getSeverity(), a.getExpiresAt(), a.getCreatedAt());
//    
//    
//    ws.convertAndSend("/topic/alerts", dto);
//    
//    notifyAllUsers(a);
//    return dto;
//  }
  
  
    private void notifyAllUsers(Alert alert) {
    List<User> users = userRepo.findAllByVerified(true);
    for (User user : users) {
      try {
        sendEmail(user.getEmail(), alert);
      } catch (Exception e) {
        log.warn("❌ Failed to email {}: {}", user.getEmail(), e.getMessage());
      }
    }
  }

    private void sendEmail(String to, Alert alert) {
  SimpleMailMessage msg = new SimpleMailMessage();
  msg.setTo(to);
  msg.setSubject("🚨 New Alert: " + alert.getTitle());
  msg.setText("Message: " + alert.getMessage() +
    "\nArea: " + alert.getArea() +
    "\nSeverity: " + alert.getSeverity() +
    "\nExpires At: " + alert.getExpiresAt());
  mail.send(msg);
  log.info("📧 Alert email sent to {}", to);
}


  private void sendEmailNotificationToUsers(Alert alert) {
    List<String> recipients = userRepo.findAll().stream()
      .map(user -> user.getEmail())
      .toList();

    for (String to : recipients) {
      try {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(to);
        msg.setSubject("🚨 New Alert: " + alert.getTitle());
        msg.setText("Message: " + alert.getMessage() +
          "\nArea: " + alert.getArea() +
          "\nSeverity: " + alert.getSeverity() +
          "\nExpires At: " + alert.getExpiresAt());
        mail.send(msg);
        log.info("📧 Alert email sent to {}", to);
      } catch (Exception e) {
        log.warn("❌ Failed to send email to {}: {}", to, e.getMessage());
      }
    }
  }
  
  @Transactional
public AlertDTO update(Long id, CreateAlertDTO in) {
    Alert existing = repo.findById(id).orElseThrow(() -> new RuntimeException("Alert not found"));
    existing.setTitle(in.title());
    existing.setMessage(in.message());
    existing.setArea(in.area());
    existing.setSeverity(in.severity());
    existing.setExpiresAt(in.expiresAt());
    existing = repo.save(existing);
    return new AlertDTO(existing.getId(), existing.getTitle(), existing.getMessage(), existing.getArea(),
                        existing.getSeverity(), existing.getExpiresAt(), existing.getCreatedAt());
}

@Transactional
public void delete(Long id) {
    repo.deleteById(id);
}


  public List<AlertDTO> activeByArea(String area) {
    return repo.findByAreaAndExpiresAtAfter(area, Instant.now())
        .stream().map(a -> new AlertDTO(a.getId(), a.getTitle(), a.getMessage(),
              a.getArea(), a.getSeverity(), a.getExpiresAt(), a.getCreatedAt()))
        .toList();
  }
  public List<AlertDTO> all() {
  return repo.findAll(Sort.by(Sort.Direction.DESC, "createdAt")) 
      .stream()
      .map(a -> new AlertDTO(
          a.getId(),
          a.getTitle(),
          a.getMessage(),
          a.getArea(),
          a.getSeverity(),
          a.getExpiresAt(),
          a.getCreatedAt()))
      .toList();
}

}
