package com.dms.dms_backend.api.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class UserDTO {
    public Long id;
    public String name;
    public String email;
    public String role;
    public String phone;
}
