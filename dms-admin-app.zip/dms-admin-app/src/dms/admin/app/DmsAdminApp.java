/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dms.admin.app;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class DmsAdminApp extends Application {
  private final Backend backend = new Backend("http://localhost:8080");

  @Override public void start(Stage stage) {
    TextField title = new TextField();  title.setPromptText("Title");
    TextArea  msg   = new TextArea();   msg.setPromptText("Message");
    TextField area  = new TextField();  area.setPromptText("Area");
    ComboBox<String> severity = new ComboBox<>();
    severity.getItems().addAll("LOW","MEDIUM","HIGH","CRITICAL");
    TextField expires = new TextField(); expires.setPromptText("ExpiresAt (ISO-8601)");

    Button send = new Button("Create Alert");
    Label status = new Label();

    send.setOnAction(e -> {
      try {
        backend.createAlert(title.getText(), msg.getText(), area.getText(),
            severity.getValue(), expires.getText());
        status.setText("Alert created!");
      } catch (Exception ex) { status.setText("Error: " + ex.getMessage()); }
    });

    VBox root = new VBox(8, title, msg, area, severity, expires, send, status);
    root.setPadding(new Insets(12));
    stage.setScene(new Scene(root, 420, 360));
    stage.setTitle("DMS Admin");
    stage.show();

    // Subscribe to alerts over WebSocket
    new Thread(() -> WebSocketClient.subscribe("ws://localhost:8080/ws", "/topic/alerts",
        body -> System.out.println("New alert: " + body))).start();
  }

  public static void main(String[] args) { launch(args); }
}
