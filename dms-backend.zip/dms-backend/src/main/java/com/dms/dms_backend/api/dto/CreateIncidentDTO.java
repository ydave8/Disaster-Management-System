package com.dms.dms_backend.api.dto;

import jakarta.validation.constraints.*;

public record CreateIncidentDTO(
  @NotBlank String type,
  @NotBlank String description,
  @DecimalMin("-90.0")  @DecimalMax("90.0")  double lat,
  @DecimalMin("-180.0") @DecimalMax("180.0") double lng
) {}
