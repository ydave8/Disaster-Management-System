package com.dms.dms_backend.service;

import com.dms.dms_backend.api.dto.CreateResourceDTO;
import com.dms.dms_backend.api.dto.ResourceDTO;
import com.dms.dms_backend.domain.Incident;
import com.dms.dms_backend.domain.Resource;
import com.dms.dms_backend.repo.IncidentRepository;
import com.dms.dms_backend.repo.ResourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class ResourceService {

    @Autowired
    private ResourceRepository resourceRepository;
    

    @Autowired
    private IncidentRepository incidentRepository;

//    @PostMapping
//    public ResponseEntity<Resource> create(@RequestBody ResourceDTO dto) {
//        // 1. Fetch Incident
//        Incident incident = incidentRepository.findById(dto.getIncidentId())
//                .orElseThrow(() -> new RuntimeException("Incident not found"));
//
//        // 2. Create Resource
//        Resource resource = new Resource();
//        resource.setType(dto.getType());
//        resource.setQuantity(dto.getQuantity());
//        resource.setIncident(incident);  // this links it
//
//        // 3. Save
//        Resource saved = resourceRepository.save(resource);
//
//        return ResponseEntity.ok(saved);
//    }
    
public ResourceDTO create(CreateResourceDTO dto) {
    Resource r = new Resource();
    r.setType(dto.getType());
    r.setDescription(dto.getDescription());
    r.setQuantity(dto.getQuantity());
    r.setLocation(dto.getLocation());

    if (dto.getIncidentId() != null) {
        Incident incident = incidentRepository.findById(dto.getIncidentId())
            .orElseThrow(() -> new RuntimeException("Incident not found"));
        r.setIncident(incident);
    }

    Resource saved = resourceRepository.save(r);
    return toDTO(saved);
}
    



//    public ResourceDTO create(CreateResourceDTO dto) {
//        Resource r = new Resource();
//        r.setType(dto.getType());
//        r.setDescription(dto.getDescription());
//        r.setQuantity(dto.getQuantity());
//        r.setLocation(dto.getLocation());
//
//        Resource saved = resourceRepository.save(r);
//        return toDTO(saved);
//    }

    public List<ResourceDTO> getAll() {
        return resourceRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

//    private ResourceDTO toDTO(Resource r) {
//        return ResourceDTO.builder()
//                .id(r.getId())
//                .type(r.getType())
//                .description(r.getDescription())
//                .quantity(r.getQuantity())
//                .location(r.getLocation())
//                .build();
//    }
    
    private ResourceDTO toDTO(Resource r) {
    return ResourceDTO.builder()
            .id(r.getId())
            .type(r.getType())
            .description(r.getDescription())
            .quantity(r.getQuantity())
            .location(r.getLocation())
            .incidentId(r.getIncident() != null ? r.getIncident().getId() : null) // ✅ Add this line
            .build();
}

    
    public ResourceDTO update(Long id, CreateResourceDTO dto) {
    Resource resource = resourceRepository.findById(id).orElseThrow(() -> new RuntimeException("Resource not found"));
    resource.setType(dto.type);
    resource.setDescription(dto.description);
    resource.setQuantity(dto.quantity);
    resource.setLocation(dto.location);
        if (dto.getIncidentId() != null) {
        Incident incident = incidentRepository.findById(dto.getIncidentId())
            .orElseThrow(() -> new RuntimeException("Incident not found"));
        resource.setIncident(incident);
    }

    Resource saved = resourceRepository.save(resource);
    return toDTO(resourceRepository.save(resource));
}

    public void delete(Long id) {
    resourceRepository.deleteById(id);
}
}
