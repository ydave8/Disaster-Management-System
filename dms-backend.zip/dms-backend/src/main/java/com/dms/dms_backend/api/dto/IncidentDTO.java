package com.dms.dms_backend.api.dto;

import com.dms.dms_backend.domain.Incident.Status;

public record IncidentDTO(
  Long id, String type, String description, double lat, double lng, Status status
) {}
