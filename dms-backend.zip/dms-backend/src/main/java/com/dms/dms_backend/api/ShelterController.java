// File: com.dms.dms_backend.api.ShelterController.java
package com.dms.dms_backend.api;

import com.dms.dms_backend.api.dto.CreateShelterDTO;
import com.dms.dms_backend.api.dto.ShelterDTO;
import com.dms.dms_backend.service.ShelterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/shelters")
public class ShelterController {

    @Autowired private ShelterService shelterService;

    @PostMapping
    public ShelterDTO create(@RequestBody CreateShelterDTO dto) {
        return shelterService.create(dto);
    }

    @GetMapping
    public List<ShelterDTO> getAll() {
        return shelterService.getAll();
    }

    @PutMapping("/{id}")
    public ShelterDTO update(@PathVariable Long id, @RequestBody CreateShelterDTO dto) {
        return shelterService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        shelterService.delete(id);
    }
}
