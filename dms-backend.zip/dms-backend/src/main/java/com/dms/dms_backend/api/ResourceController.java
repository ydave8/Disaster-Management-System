package com.dms.dms_backend.api;


import com.dms.dms_backend.api.dto.CreateResourceDTO;
import com.dms.dms_backend.api.dto.ResourceDTO;
import com.dms.dms_backend.service.ResourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//@RestController
//@RequestMapping("/api/v1/resources")
//public class ResourceController {
//
//    @Autowired
//    private ResourceRepository resourceRepository;
//
//    @Autowired
//    private IncidentRepository incidentRepository;
//
//    @PostMapping
//    public ResponseEntity<Resource> create(@RequestBody ResourceDTO dto) {
//        // 1. Fetch Incident
//        Incident incident = incidentRepository.findById(dto.getIncidentId())
//                .orElseThrow(() -> new RuntimeException("Incident not found"));
//
//        // 2. Create Resource
//        Resource resource = new Resource();
//        resource.setType(dto.getType());
//        resource.setQuantity(dto.getQuantity());
//        resource.setIncident(incident);  // <-- this links it
//
//        // 3. Save
//        Resource saved = resourceRepository.save(resource);
//
//        return ResponseEntity.ok(saved);
//    }
//}


@RestController
@RequestMapping("/api/v1/resources")
public class ResourceController {


@Autowired
private ResourceService resourceService;


@PostMapping
public ResourceDTO create(@RequestBody CreateResourceDTO dto) {
return resourceService.create(dto);
}


@PutMapping("/{id}")
public ResourceDTO update(@PathVariable Long id, @RequestBody CreateResourceDTO dto) {
    return resourceService.update(id, dto);
}

@DeleteMapping("/{id}")
public void delete(@PathVariable Long id) {
    resourceService.delete(id);
}

@GetMapping
public List<ResourceDTO> getAll() {
return resourceService.getAll();
}
}