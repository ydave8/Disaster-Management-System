package com.dms.dms_backend.api;

import com.dms.dms_backend.api.dto.*;
import com.dms.dms_backend.domain.Incident;
import com.dms.dms_backend.domain.Incident.Status;
import com.dms.dms_backend.repo.IncidentRepository;
import com.dms.dms_backend.service.IncidentService;
import com.dms.dms_backend.service.PdfReportService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/incidents")
public class IncidentController {
  private static final Logger log = LoggerFactory.getLogger(IncidentController.class); // ← add this

  private final IncidentService service;
  private final IncidentRepository incidentRepo;
  private final PdfReportService pdfReportService;

  @PostMapping
  public ResponseEntity<IncidentDTO> create(@Valid @RequestBody CreateIncidentDTO in){
    var dto = service.create(in);
    return ResponseEntity.ok(dto);
  }

  @GetMapping
  public List<IncidentDTO> list(@RequestParam(required=false) Status status){
    return service.list(status);
  }

  @PatchMapping("/{id}/status")
  public IncidentDTO setStatus(@PathVariable Long id, @RequestParam Status status){
    return service.updateStatus(id, status);
  }

  @GetMapping("/{id}/report")
  public ResponseEntity<byte[]> generateReport(@PathVariable Long id) throws Exception {
    log.info("🔍 Fetching report for incident ID: {}", id);

    Incident incident = incidentRepo.findById(id)
        .orElseThrow(() -> new RuntimeException("Incident not found"));

    byte[] pdf = pdfReportService.generateIncidentReport(incident);

    return ResponseEntity.ok()
        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=incident-" + id + ".pdf")
        .contentType(MediaType.APPLICATION_PDF)
        .body(pdf);
  }

  @PutMapping("/{id}")
  public IncidentDTO update(@PathVariable Long id, @RequestBody CreateIncidentDTO in) {
    return service.update(id, in);
  }
  
  @GetMapping("/{id}")
public IncidentDTO getIncidentById(@PathVariable Long id) {
    return service.getIncidentById(id);
}


  @DeleteMapping("/{id}")
  public void delete(@PathVariable Long id) {
    service.delete(id);
  }
}
