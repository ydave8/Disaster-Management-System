// File: com.dms.dms_backend.repo.ShelterRepository.java
package com.dms.dms_backend.repo;

import com.dms.dms_backend.domain.Shelter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShelterRepository extends JpaRepository<Shelter, Long> {}
