//package com.dms.dms_backend.api.dto;
//
//import lombok.*;
//
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//@Builder
//public class ResourceDTO {
//    private Long id;
//    private String type;
//    private String description;
//    private int quantity;
//    private String location;
//    public Long incidentId;
//}


package com.dms.dms_backend.api.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResourceDTO {
    private Long id;               // optional for update
    private String type;           // e.g. "Water", "Medicines"
    private String description;    // optional details
    private int quantity;          // how many units
    private String location;       // optional (e.g., "Zone A")
    private Long incidentId;       // important! links to incident
}
