package com.dms.dms_backend.api;

import com.dms.dms_backend.api.dto.CreateUserDTO;
import com.dms.dms_backend.api.dto.LoginDTO;
import com.dms.dms_backend.domain.User;
import com.dms.dms_backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<User> create(@RequestBody CreateUserDTO dto) {
        return ResponseEntity.ok(userService.create(dto));
    }

    @GetMapping
    public ResponseEntity<List<User>> getAll() {
        return ResponseEntity.ok(userService.getAll());
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> update(@PathVariable Long id, @RequestBody CreateUserDTO dto) {
        return ResponseEntity.ok(userService.update(id, dto));
    }
    
    @PostMapping("/login")
public ResponseEntity<String> login(@RequestBody LoginDTO dto) {
    userService.login(dto);
    return ResponseEntity.ok("Login successful");
}

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        userService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
