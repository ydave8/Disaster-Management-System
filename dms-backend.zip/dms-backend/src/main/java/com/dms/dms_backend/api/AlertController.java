/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dms.dms_backend.api;

/**
 *
 * @author Yatharth
 */
import com.dms.dms_backend.api.dto.AlertDTO;
import com.dms.dms_backend.api.dto.CreateAlertDTO;
import com.dms.dms_backend.service.AlertService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/alerts")
@RequiredArgsConstructor
public class AlertController {
  private final AlertService service;

  @PostMapping
  public AlertDTO create(@Valid @RequestBody CreateAlertDTO in) { return service.createAndBroadcast(in); }

//  @GetMapping
//  public List<AlertDTO> query(@RequestParam String area) { return service.activeByArea(area); }
@GetMapping
public List<AlertDTO> query(@RequestParam(required = false) String area) {
  if (area != null && !area.isEmpty()) {
    return service.activeByArea(area);
  } else {
    return service.all(); // You’ll need to add this method if it doesn’t exist yet
  }
}

@PutMapping("/{id}")
public AlertDTO update(@PathVariable Long id, @Valid @RequestBody CreateAlertDTO in) {
    return service.update(id, in);
}

@DeleteMapping("/{id}")
public void delete(@PathVariable Long id) {
    service.delete(id);
}

  
}
