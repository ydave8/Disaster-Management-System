package com.dms.dms_backend.repo;

import com.dms.dms_backend.domain.SosRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SosRepository extends JpaRepository<SosRequest, Long> {}
