package com.dms.dms_backend.service;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

@Service
public class SeverityPredictionService {
    private final RestTemplate rest = new RestTemplate();
    private final String endpoint = "http://localhost:5001/predict-severity";

    public String predictSeverity(String title, String message) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        Map<String, String> body = Map.of("title", title, "message", message);

        HttpEntity<Map<String, String>> request = new HttpEntity<>(body, headers);
        ResponseEntity<Map> response = rest.postForEntity(endpoint, request, Map.class);

        return (String) response.getBody().get("severity");
    }
}
