package dms.admin.app;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Backend {
  private final String base;
  private final HttpClient http = HttpClient.newHttpClient();

  public Backend(String base){ this.base = base; }

  public void createAlert(String title, String message, String area,
                          String severity, String expiresAt) throws Exception {
    String json = "{\"title\":\""+esc(title)+"\",\"message\":\""+esc(message)+"\","
        + "\"area\":\""+esc(area)+"\",\"severity\":\""+severity+"\","
        + "\"expiresAt\":\""+expiresAt+"\"}";
    HttpRequest req = HttpRequest.newBuilder(URI.create(base + "/api/v1/alerts"))
        .header("Content-Type", "application/json")
        .POST(HttpRequest.BodyPublishers.ofString(json))
        .build();
    HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
    if (res.statusCode() >= 300) {
      throw new RuntimeException("HTTP " + res.statusCode() + ": " + res.body());
    }
  }

  private static String esc(String s) {
    return s == null ? "" : s.replace("\\","\\\\").replace("\"","\\\"");
  }
}

