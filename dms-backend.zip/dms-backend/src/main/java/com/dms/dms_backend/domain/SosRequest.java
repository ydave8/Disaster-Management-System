package com.dms.dms_backend.domain;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Timestamp;

@Entity
@Table(name = "sos_requests")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SosRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userEmail;
    private Double latitude;
    private Double longitude;

    @Column(columnDefinition = "TEXT")
    private String note;

    private Timestamp createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = new Timestamp(System.currentTimeMillis());
    }
}
